<?php

$lang['js']['button'] = 'Insert video from video sharing sites';
$lang['js']['prompt'] = 'Please paste the full URL to the video page here:';
$lang['js']['notfound'] = "Sorry, this URL wasn't recognized.\nPlease refer to the documentation on how to insert the correct syntax manually.";

