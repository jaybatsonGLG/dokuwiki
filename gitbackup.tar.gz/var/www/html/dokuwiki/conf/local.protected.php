<?php
// general DokuWiki options
$conf['useacl']         = 1;
$conf['authtype']       = 'authad';
// configure your Active Directory data here
$conf['plugin']['authad']['account_suffix']     = '@glg.lcl';
$conf['plugin']['authad']['base_dn']            = 'DC=glg,DC=lcl';
$conf['plugin']['authad']['domain_controllers'] = 'slcv-dc02.glg.lcl'; //multiple can be given
$conf['plugin']['authad']['recursive_groups']   = 1;
$conf['manager']   = '@Domain_Users';
$conf['superuser'] = '@Domain_Users';

